<!-- markdown -->

If you're experiencing delays in scheduled jobs or they don't seem to run, you run run the following command to diagnose the issue.

`bench doctor`

A desirable output is like below


	Workers online: True
	Pending tasks 0
	Timed out locks:


We'll be adding more health checks soon.
