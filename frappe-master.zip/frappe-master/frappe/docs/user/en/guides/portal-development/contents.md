# Table of Contents

You can add a table of contents by adding `{index}` string on a new line.

You can also make Previous and Next buttons by adding `previous` or `next` in `{}`

### Showing contents

    # This is a title
    
    Hello paragraph
    
    ### Contents:
    
    {index}

{next}
