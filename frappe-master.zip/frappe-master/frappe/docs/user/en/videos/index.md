# Video Tutorials for Frappe Framework

This 10-part video tutorial will teach you how to build complex apps in Frappe

Pre-requisites: <a href="{{ docs_base_url }}/user/en/tutorial/before.html" target="_blank">You must have some understanding of Python, Javascript and MySQL before you start this tutorial.</a>

---

<iframe width="670" height="376" src="https://www.youtube.com/embed/videoseries?list=PL3lFfCEoMxvzHtsZHFJ4T3n5yMM3nGJ1W" frameborder="0" allowfullscreen></iframe>
