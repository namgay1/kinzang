Dashboard Frappe
=================
This project is a frappe application which integrate [sDashboard](https://github.com/ModelN/sDashboard) with frappe framework.
You can make your own Dashboard by defining widget and widget report.

Features
--------
 1. Table Widget
 2. Tab Widget
 3. Chart Widget (using Flotr2)

How to Install
==============

 1. Get Dashboard application with `bench get-app dashboard https://github.com/Athenolabs/dashboard.git`
 2. Install application in the framework with `bench install-app dashboard` 

How to use it?
==============
 1. Create Widget Report
 1. Create Widget (Table/Tab/Chart)


Sample Data
===========


Sample Report Query
===================


