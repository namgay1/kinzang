# Reports

You can also click on the Reports text on the sidebar (left) to see tabulated records

<img class="screenshot" alt="Report" src="{{docs_base_url}}/assets/img/report.png">

{next}
