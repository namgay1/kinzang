# Ordering

You can defining the ordering of pages in index by defining the index.txt file in your folder. The index.txt file must have the names (without extensions) of the pages in that folder indicating the order.

For example for this folder the `index.txt` looks like:

    adding-pages
    ordering
    contents
    context
    building

{next}
