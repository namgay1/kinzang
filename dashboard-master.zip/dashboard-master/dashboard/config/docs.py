"""
Configuration for docs
"""

source_link = "https://github.com/sanjay-kumar001/dashboard.git"
docs_base_url = "https://sanjay-kumar001.github.io/dashboard"
headline = "App that does everything"
sub_heading = "Yes, you got that right the first time, everything"
long_description = """(long description in markdown)"""

def get_context(context):
	# optional settings

	# context.brand_html = 'Dashboard'
	# context.favicon = 'path to favicon'
	#
	# context.top_bar_items = [
	#   {"label": "About", "url": context.docs_base_url + "/about"},
	# ]
	pass
