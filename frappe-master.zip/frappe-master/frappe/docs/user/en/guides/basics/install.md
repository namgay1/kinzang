# Installing Frappe

## Frappe bench

The following steps help you setup an isolated environment (bench) to run and
develop Frappe apps. A virtualenv is installed in the env directory. You can
activate it by running `source ./env/bin/activate` or use execute using
absolute/relative path (eg, `./env/bin/frappe`).

For more info, see [Frappe Bench](https://github.com/frappe/bench/)
