// Copyright (c) 2016, {app_publisher} and contributors
// For license information, please see license.txt

frappe.query_reports["{name}"] = {{
	"filters": [

	]
}}
