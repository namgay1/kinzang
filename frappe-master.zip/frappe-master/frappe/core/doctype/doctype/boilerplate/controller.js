// Copyright (c) 2016, {app_publisher} and contributors
// For license information, please see license.txt

frappe.ui.form.on('{doctype}', {{
	refresh: function(frm) {{

	}}
}});
